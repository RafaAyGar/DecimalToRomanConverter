package business.util;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.Test;

public class DecimalNumberScannerTest extends DecimalNumberScanner{

}
