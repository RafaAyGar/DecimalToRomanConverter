package business.util;

public class MyPrinter {

    public static void print(String text)
    {
        System.out.println(text);
    }
}
